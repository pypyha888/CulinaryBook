﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using WpfApp1.ApplicationData;

namespace WpfApp1.Pages
{
    /// <summary>
    /// 📜 Страница шагов приготовления рецепта
    /// </summary>
    public partial class PageShagi : Page
    {
        // 📦 Текущий рецепт
        private Recipes _recipe;

        public PageShagi(Recipes recipe)
        {
            InitializeComponent();
            _recipe = recipe;

            // 🏷️ Заголовок с названием рецепта
            txtRecipeName.Text = recipe.RecipeName;

            // 📋 Загружаем шаги
            LoadSteps();

            // 🔢 Ставим следующий номер шага автоматически
            SetNextStepNumber();
        }

        /// <summary>
        /// 📋 Загрузка шагов из БД
        /// </summary>
        private void LoadSteps()
        {
            var steps = AppConnect.model01.CookingSteps
                .Where(s => s.RecipeID == _recipe.RecipeID)
                .OrderBy(s => s.StepNumber)
                .ToList();

            StepsList.ItemsSource = null;
            StepsList.ItemsSource = steps;

            txtCounter.Text = $"Всего шагов: {steps.Count}";
        }

        /// <summary>
        /// 🔢 Автоматически ставим следующий номер шага
        /// </summary>
        private void SetNextStepNumber()
        {
            var lastStep = AppConnect.model01.CookingSteps
                .Where(s => s.RecipeID == _recipe.RecipeID)
                .OrderByDescending(s => s.StepNumber)
                .FirstOrDefault();

            StepNumberBox.Text = lastStep != null
                ? (lastStep.StepNumber + 1).ToString()
                : "1";
        }

        /// <summary>
        /// ✅ Добавить шаг
        /// </summary>
        private void AddStep_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(StepDescBox.Text))
            {
                MessageBox.Show("Введите описание шага!", "📖 Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!int.TryParse(StepNumberBox.Text, out int stepNum) || stepNum <= 0)
            {
                MessageBox.Show("Введите корректный номер шага!", "📖 Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                var newStep = new CookingSteps
                {
                    RecipeID = _recipe.RecipeID,
                    StepNumber = stepNum,
                    StepDescription = StepDescBox.Text.Trim()
                };

                AppConnect.model01.CookingSteps.Add(newStep);
                AppConnect.model01.SaveChanges();

                // 🔄 Обновляем список и поля
                StepDescBox.Text = "";
                LoadSteps();
                SetNextStepNumber();

                MessageBox.Show($"✨ Шаг {stepNum} добавлен!", "✅ Успех",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"💥 Ошибка:\n{ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// 🗑️ Удалить выбранный шаг
        /// </summary>
        private void DeleteStep_Click(object sender, RoutedEventArgs e)
        {
            if (StepsList.SelectedItem is CookingSteps selected)
            {
                var result = MessageBox.Show(
                    $"Удалить шаг {selected.StepNumber}?", "🗑️ Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        AppConnect.model01.CookingSteps.Remove(selected);
                        AppConnect.model01.SaveChanges();
                        LoadSteps();
                        SetNextStepNumber();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"💥 Ошибка:\n{ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите шаг для удаления!", "📖 Уведомление",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        /// <summary>
        /// 📝 Клик по шагу — подставляем данные в поля для редактирования
        /// </summary>
        private void StepsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StepsList.SelectedItem is CookingSteps selected)
            {
                StepNumberBox.Text = selected.StepNumber.ToString();
                StepDescBox.Text = selected.StepDescription;
            }
        }

        /// <summary>
        /// ⬅️ Назад к рецепту
        /// </summary>
        private void BackToRecipe_Click(object sender, RoutedEventArgs e)
        {
            ApplicationData.AppFrame.frmMain.Navigate(new AddRecip(_recipe));
        }

        /// <summary>
        /// 🏠 К списку рецептов
        /// </summary>
        private void BackToList_Click(object sender, RoutedEventArgs e)
        {
            ApplicationData.AppFrame.frmMain.Navigate(new PageTask());
        }
    }
}
